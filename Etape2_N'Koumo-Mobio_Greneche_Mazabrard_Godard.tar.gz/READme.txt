Monsieur,

Vous pouvez economiser du temps en skippant les tests de robustesse sur notre code : il ne fonctionne pas.

Nous avons voulu vous envoyer ce que nous avions fait pour vous montrer qu'il n'y avait pas rien, mais que nous avions sous-estime le temps necessaire a la realisation du parseur (nous n'etions pas parti sur la bonne structure puis les 2 semaines sont passees plutot vite).

Par suite, nous avons manque de temps pour finir l'etape 2 et sommes conscients d'avoir merde.

Depuis mardi, avec d'autres matieres a travailler et des choses a y preparer/rendre, nous n'avons pas pu completer/finir/debugger ce que nous avions commence pour ce jeudi et avons prefere se dire que nous sommes totalement passes a cote de cette etape, mais qu'avec votre parseur la prochaine n'en subira pas les consequences.

Ainsi, dans cette archive, vous trouverez l'API qui a ete codee selon notre structure et ne presente pas de bugs, notre structure et ses fonctions rattachees ainsi que quelques fonctions qui etaient destinees au parseur (en commentaire sont les instructions non terminees ou provoquant des erreurs lors de la compilation).

Veuillez nous excuser pour ce manquement, nous serons dans les temps pour l'etape 3.

Bien a vous,
Stephane N'Koumo-Mobio
Gabriel Mazabrard
Lucas Greneche
Evann Godard

